import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Plus, Mail, Phone, MoreVertical, Shield, UserCog, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const Team = () => {
  const { toast } = useToast();

  const teamMembers = [
    {
      id: 1,
      name: 'John Smith',
      email: 'john@example.com',
      phone: '+1 234 567 8900',
      role: 'Admin',
      status: 'Active',
      conversations: 245,
      responseTime: '2.1 min',
      avatar: 'JS'
    },
    {
      id: 2,
      name: 'Sarah Johnson',
      email: 'sarah@example.com',
      phone: '+1 234 567 8901',
      role: 'Agent',
      status: 'Active',
      conversations: 189,
      responseTime: '2.8 min',
      avatar: 'SJ'
    },
    {
      id: 3,
      name: 'Mike Wilson',
      email: 'mike@example.com',
      phone: '+1 234 567 8902',
      role: 'Agent',
      status: 'Active',
      conversations: 156,
      responseTime: '3.2 min',
      avatar: 'MW'
    },
    {
      id: 4,
      name: 'Emily Brown',
      email: 'emily@example.com',
      phone: '+1 234 567 8903',
      role: 'Supervisor',
      status: 'Away',
      conversations: 98,
      responseTime: '2.5 min',
      avatar: 'EB'
    },
  ];

  const handleAction = (action) => {
    toast({
      title: "🚧 Feature Coming Soon!",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const getRoleColor = (role) => {
    switch (role) {
      case 'Admin':
        return 'bg-purple-100 text-purple-700';
      case 'Supervisor':
        return 'bg-blue-100 text-blue-700';
      case 'Agent':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-green-500';
      case 'Away':
        return 'bg-orange-500';
      case 'Offline':
        return 'bg-gray-400';
      default:
        return 'bg-gray-400';
    }
  };

  return (
    <>
      <Helmet>
        <title>Team - WhatsApp Business Platform</title>
        <meta name="description" content="Manage your team members, roles, and permissions for WhatsApp Business collaboration." />
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Team Management</h2>
            <p className="text-gray-600 mt-1">Manage team members and their permissions</p>
          </div>
          <Button onClick={() => handleAction('invite')} className="whatsapp-gradient text-white rounded-xl">
            <Plus className="w-4 h-4 mr-2" />
            Invite Member
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { label: 'Total Members', value: '12', icon: Users, color: 'from-blue-500 to-blue-600' },
            { label: 'Active Now', value: '8', icon: UserCog, color: 'from-green-500 to-green-600' },
            { label: 'Admins', value: '3', icon: Shield, color: 'from-purple-500 to-purple-600' },
            { label: 'Agents', value: '9', icon: Users, color: 'from-orange-500 to-orange-600' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="glass-effect rounded-xl p-6 shadow-lg"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-gray-600 font-medium">{stat.label}</p>
                  <p className={`text-2xl font-bold mt-1 bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>
                    {stat.value}
                  </p>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Team Members Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {teamMembers.map((member, index) => (
            <motion.div
              key={member.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="glass-effect rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg">
                      {member.avatar}
                    </div>
                    <div className={`absolute bottom-0 right-0 w-4 h-4 ${getStatusColor(member.status)} border-2 border-white rounded-full`}></div>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">{member.name}</h3>
                    <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium mt-1 ${getRoleColor(member.role)}`}>
                      {member.role}
                    </span>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleAction('more')}
                >
                  <MoreVertical className="w-5 h-5" />
                </Button>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Mail className="w-4 h-4" />
                  <span>{member.email}</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Phone className="w-4 h-4" />
                  <span>{member.phone}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-200">
                <div className="bg-white/50 rounded-xl p-3">
                  <p className="text-xs text-gray-600 mb-1">Conversations</p>
                  <p className="text-xl font-bold text-gray-900">{member.conversations}</p>
                </div>
                <div className="bg-white/50 rounded-xl p-3">
                  <p className="text-xs text-gray-600 mb-1">Avg Response</p>
                  <p className="text-xl font-bold text-green-600">{member.responseTime}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Roles & Permissions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-effect rounded-2xl p-8 shadow-lg"
        >
          <h3 className="text-xl font-bold text-gray-900 mb-6">Roles & Permissions</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                role: 'Admin',
                color: 'from-purple-500 to-purple-600',
                permissions: ['Full access', 'Manage team', 'View analytics', 'Configure settings']
              },
              {
                role: 'Supervisor',
                color: 'from-blue-500 to-blue-600',
                permissions: ['View analytics', 'Manage agents', 'Access inbox', 'Create broadcasts']
              },
              {
                role: 'Agent',
                color: 'from-green-500 to-green-600',
                permissions: ['Access inbox', 'Reply to messages', 'View contacts', 'Use templates']
              },
            ].map((roleInfo, index) => (
              <div key={index} className="bg-white/50 rounded-xl p-6">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${roleInfo.color} flex items-center justify-center mb-4 shadow-lg`}>
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <h4 className="text-lg font-bold text-gray-900 mb-3">{roleInfo.role}</h4>
                <ul className="space-y-2">
                  {roleInfo.permissions.map((permission, i) => (
                    <li key={i} className="text-sm text-gray-600 flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                      <span>{permission}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default Team;
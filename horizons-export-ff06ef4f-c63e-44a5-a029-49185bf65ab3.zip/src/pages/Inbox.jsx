import React, { useState, useEffect, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Send, File, Lightbulb, MoreVertical, ArrowLeft, Mic, User, Copy, X, Check, CheckCheck, Trash2, MessageSquare, StickyNote } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
} from '@/components/ui/dialog';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const initialConversations = [
  { id: 1, name: 'John Doe', number: '+1 555-123-4567', avatar: 'JD' },
  { id: 2, name: 'Sarah Wilson', number: '+44 20 7946 0958', avatar: 'SW' },
  { id: 3, name: 'Mike Johnson', number: '+61 2 9876 5432', avatar: 'MJ' },
  { id: 4, name: 'Emily Brown', number: '+1 212-555-0182', avatar: 'EB' },
];

const initialMessages = {
  1: [
    { id: 1, text: 'Hi! I need help with my order', sent: false, time: '10:30 AM', type: 'text', read: false },
    { id: 2, text: 'Hello! I\'d be happy to help. What\'s your order number?', sent: true, time: '10:31 AM', type: 'text', status: 'read' },
    { id: 3, text: 'It\'s #12345', sent: false, time: '10:32 AM', type: 'text', read: false },
    { id: 4, text: 'Your order is being processed and will ship tomorrow!', sent: true, time: '10:34 AM', type: 'text', status: 'sent' },
  ],
  2: [
    { id: 1, text: 'Can you send me the details?', sent: false, time: '10:45 AM', type: 'text', read: false },
    { id: 2, text: 'Of course, which details are you referring to?', sent: true, time: '10:46 AM', type: 'text', status: 'read' },
  ],
  3: [
    { id: 1, text: 'Perfect, see you tomorrow!', sent: false, time: '11:00 AM', type: 'text', read: false },
  ],
  4: [
     { id: 1, text: 'I have a question about billing.', sent: false, time: '11:15 AM', type: 'text', read: false },
     { id: 2, text: 'I can help with that. What is your question?', sent: true, time: '11:16 AM', type: 'text', status: 'delivered' },
  ],
};

const allTemplates = [
    { id: 1, name: 'Order Confirmation', status: 'Approved', content: 'Hi {{1}}, your order #{{2}} has been confirmed! Expected delivery: {{3}}' },
    { id: 2, name: 'Appointment Reminder', status: 'Approved', content: 'Hello {{1}}, this is a reminder for your appointment on {{2}} at {{3}}.' },
    { id: 3, name: 'Welcome Message', status: 'Pending', content: 'Welcome to {{1}}! We\'re excited to have you. Use code {{2}} for 10% off your first order.'},
    { id: 4, name: 'Payment Received', status: 'Approved', content: 'Payment of {{1}} received for invoice #{{2}}. Thank you!'},
    { id: 5, name: 'Shipping Update', status: 'Rejected', content: 'Your order is on the way! Track it here: {{1}}'},
];

const approvedTemplates = allTemplates.filter(t => t.status === 'Approved');

const stickers = ['👍', '🎉', '❤️', '😂', '🙏', '🔥', '🚀', '💯', '👋', '😎', '✅', '🥳'];


const Inbox = () => {
  const { toast } = useToast();
  const [allMessages, setAllMessages] = useState(() => {
    try {
      const savedMessages = localStorage.getItem('allMessages');
      return savedMessages ? JSON.parse(savedMessages) : initialMessages;
    } catch (error) {
      return initialMessages;
    }
  });

  const [selectedChatId, setSelectedChatId] = useState(1);
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const recordingIntervalRef = useRef(null);
  const fileInputRef = useRef(null);
  const [isProfileDialogOpen, setIsProfileDialogOpen] = useState(false);
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('allMessages', JSON.stringify(allMessages));
  }, [allMessages]);

  useEffect(() => {
    if (selectedChatId) {
      setAllMessages(prev => {
        const updatedMessages = { ...prev };
        const chatMessages = updatedMessages[selectedChatId] || [];
        
        const hasUnread = chatMessages.some(m => !m.sent && !m.read);
        if (!hasUnread) {
          return prev; 
        }

        updatedMessages[selectedChatId] = chatMessages.map(m => 
          !m.sent && !m.read ? { ...m, read: true } : m
        );
        return updatedMessages;
      });
    }
  }, [selectedChatId]);


  const conversations = initialConversations.map(conv => {
    const chatMessages = allMessages[conv.id] || [];
    const lastMessage = chatMessages[chatMessages.length - 1];
    const unreadCount = chatMessages.filter(m => !m.sent && !m.read).length;
    
    return {
      ...conv,
      lastMessage: lastMessage ? lastMessage.text : "No messages yet",
      time: lastMessage ? lastMessage.time : "",
      unread: unreadCount,
    };
  }).sort((a, b) => {
    const timeA = allMessages[a.id]?.[allMessages[a.id].length - 1]?.id || 0;
    const timeB = allMessages[b.id]?.[allMessages[b.id].length - 1]?.id || 0;
    return timeB - timeA;
  });

  const currentMessages = allMessages[selectedChatId] || [];

  const addMessageToChat = (text, type = 'text') => {
      const newMessage = {
        id: Date.now(),
        text,
        sent: true,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type,
        status: 'sent',
      };
      setAllMessages(prev => ({ ...prev, [selectedChatId]: [...(prev[selectedChatId] || []), newMessage] }));
  }

  const handleSendMessage = () => {
    if (message.trim()) {
      addMessageToChat(message.trim());
      setMessage('');
    }
  };
  
  const handleSendVoiceMessage = () => {
    if (isRecording) {
      stopRecording(false);
      addMessageToChat(`Voice message (${formatDuration(recordingDuration)})`, 'audio');
      setRecordingDuration(0);
      toast({
        title: "Voice Message Sent! 🎙️",
        description: "Your voice message has been delivered.",
      });
    }
  };

  const handleSendTemplate = (templateContent) => {
    addMessageToChat(templateContent);
    setIsPopoverOpen(false);
    toast({
        title: "Template Sent! ✨",
        description: "The template message has been sent to the customer.",
    });
  }

  const handleSendSticker = (sticker) => {
    addMessageToChat(sticker, 'sticker');
    setIsPopoverOpen(false);
     toast({
        title: "Sticker Sent! 🥳",
        description: `Sticker ${sticker} has been sent.`,
    });
  }

  const startRecording = () => {
    setIsRecording(true);
    recordingIntervalRef.current = setInterval(() => {
      setRecordingDuration(prev => prev + 1);
    }, 1000);
    toast({
      title: 'Recording Started...',
      description: 'The microphone is now active.'
    });
  };

  const stopRecording = (cancelled = false) => {
    setIsRecording(false);
    clearInterval(recordingIntervalRef.current);
    if (cancelled) {
        setRecordingDuration(0);
        toast({
          title: 'Recording Cancelled',
          variant: 'destructive',
        });
    }
  };
  
  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to Clipboard! 📋",
      description: "The customer's number has been copied.",
    });
  };

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      addMessageToChat(`File: ${file.name}`, 'file');
      toast({
        title: "File Sent! 📄",
        description: `${file.name} has been sent.`,
      });
    }
    event.target.value = null;
  };

  const selectedChat = conversations.find(c => c.id === selectedChatId);

  const MessageStatus = ({ status }) => {
    if (status === 'read') return <CheckCheck className="w-4 h-4 text-blue-500" />;
    if (status === 'delivered') return <CheckCheck className="w-4 h-4 text-gray-500" />;
    if (status === 'sent') return <Check className="w-4 h-4 text-gray-500" />;
    return null;
  };
  
  const MessageContent = ({ msg }) => {
      if(msg.type === 'sticker') {
          return <p className="text-4xl">{msg.text}</p>
      }
      return <p className="text-sm text-gray-900">{msg.text}</p>
  }

  const ProfileDialogContent = ({ chat }) => (
    <DialogContent className="sm:max-w-[425px]">
      <DialogHeader>
        <DialogTitle>Customer Profile</DialogTitle>
        <DialogDescription>Details for {chat.name}.</DialogDescription>
      </DialogHeader>
      <div className="py-4 space-y-4">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
            {chat.avatar}
          </div>
          <div className="flex-1">
            <p className="font-semibold text-lg text-gray-900">{chat.name}</p>
          </div>
        </div>
        <div className="flex items-center justify-between p-3 bg-gray-100 rounded-lg">
          <p className="text-sm text-gray-700">{chat.number}</p>
          <Button variant="ghost" size="icon" onClick={() => copyToClipboard(chat.number)}>
            <Copy className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </DialogContent>
  );

  return (
    <>
      <Helmet>
        <title>Inbox - WhatsApp Business Platform</title>
        <meta name="description" content="Manage all your WhatsApp conversations in one unified inbox with real-time messaging." />
      </Helmet>
      
      <Dialog open={isProfileDialogOpen} onOpenChange={setIsProfileDialogOpen}>
        {selectedChat && <ProfileDialogContent chat={selectedChat} />}
      </Dialog>
      <input type="file" ref={fileInputRef} onChange={handleFileSelect} className="hidden" />

      <div className="h-[calc(100vh-12rem)] glass-effect rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex h-full">
          <div
            className={cn(
              'w-full md:w-96 border-r border-gray-200 flex-col bg-white/50 transition-all duration-300 ease-in-out',
              'md:flex',
              selectedChatId && 'hidden'
            )}
          >
            <div className="p-4 border-b border-gray-200">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search conversations..."
                  className="w-full pl-10 pr-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto">
              {conversations.map((conv) => (
                <motion.div
                  key={conv.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: (conv.id - 1) * 0.05 }}
                  onClick={() => setSelectedChatId(conv.id)}
                  className={`p-4 border-b border-gray-100 cursor-pointer transition-colors ${
                    selectedChatId === conv.id ? 'md:bg-green-50' : ''
                  } hover:bg-gray-50`}
                >
                  <div className="flex items-start space-x-3">
                    <button onClick={(e) => { e.stopPropagation(); setSelectedChatId(conv.id); setIsProfileDialogOpen(true); }} className="relative focus:outline-none">
                      <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center text-white font-bold">
                        {conv.avatar}
                      </div>
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-gray-900 truncate">{conv.name}</h4>
                        <span className="text-xs text-gray-500">{conv.time}</span>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <p className="text-sm text-gray-600 truncate flex-1">{conv.lastMessage}</p>
                        {conv.unread > 0 && (
                          <div className="ml-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center text-xs text-white font-bold shrink-0">
                            {conv.unread}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
          
          <AnimatePresence>
            {selectedChat && (
              <motion.div
                key={selectedChat.id}
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '0%' }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className={cn(
                  'w-full flex-1 flex-col bg-gradient-to-br from-green-50/30 to-emerald-50/30',
                  'md:flex',
                  selectedChatId ? 'flex' : 'hidden'
                )}
              >
                <div className="p-4 bg-white/80 backdrop-blur-lg border-b border-gray-200 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setSelectedChatId(null)}>
                      <ArrowLeft className="w-5 h-5" />
                    </Button>
                    <button onClick={() => setIsProfileDialogOpen(true)} className="focus:outline-none">
                      <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center text-white font-bold">
                        {selectedChat.avatar}
                      </div>
                    </button>
                    <div>
                      <h3 className="font-semibold text-gray-900">{selectedChat.name}</h3>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="w-5 h-5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onSelect={() => setIsProfileDialogOpen(true)}>
                        <User className="mr-2 h-4 w-4" />
                        <span>Visit Profile</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {currentMessages.map((msg) => (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${msg.sent ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`chat-bubble ${msg.sent ? 'chat-bubble-sent' : 'chat-bubble-received'}`}>
                        <MessageContent msg={msg} />
                        <div className="flex items-center justify-end mt-1">
                          <span className="text-xs text-gray-500 mr-1">{msg.time}</span>
                          {msg.sent && <MessageStatus status={msg.status} />}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="p-4 bg-white/80 backdrop-blur-lg border-t border-gray-200">
                    <div className="flex items-center space-x-2">
                      {!isRecording && (
                        <>
                          <Popover open={isPopoverOpen} onOpenChange={setIsPopoverOpen}>
                            <PopoverTrigger asChild>
                               <Button variant="ghost" size="icon">
                                <Lightbulb className="w-5 h-5" />
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-96 p-0">
                               <Tabs defaultValue="templates" className="w-full">
                                <TabsList className="grid w-full grid-cols-2">
                                  <TabsTrigger value="templates"><MessageSquare className="mr-2 h-4 w-4" />Templates</TabsTrigger>
                                  <TabsTrigger value="stickers"><StickyNote className="mr-2 h-4 w-4" />Stickers</TabsTrigger>
                                </TabsList>
                                <TabsContent value="templates" className="p-2 max-h-64 overflow-y-auto">
                                    <div className="flex flex-col space-y-2">
                                        {approvedTemplates.map(template => (
                                            <div key={template.id} className="flex items-center justify-between p-2 rounded-md hover:bg-gray-100">
                                                <p className="text-sm text-gray-700 flex-1 mr-2">{template.content}</p>
                                                <Button size="sm" variant="ghost" onClick={() => handleSendTemplate(template.content)}>
                                                    <Send className="h-4 w-4"/>
                                                </Button>
                                            </div>
                                        ))}
                                    </div>
                                </TabsContent>
                                <TabsContent value="stickers" className="p-4">
                                    <div className="grid grid-cols-4 gap-4">
                                        {stickers.map((sticker, index) => (
                                            <button 
                                                key={index}
                                                onClick={() => handleSendSticker(sticker)} 
                                                className="text-4xl p-2 rounded-lg hover:bg-gray-200 transition-colors">
                                                {sticker}
                                            </button>
                                        ))}
                                    </div>
                                </TabsContent>
                              </Tabs>
                            </PopoverContent>
                          </Popover>
                          <Button variant="ghost" size="icon" onClick={() => fileInputRef.current.click()}>
                            <File className="w-5 h-5" />
                          </Button>
                          <input
                            type="text"
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                            placeholder="Type a message..."
                            className="flex-1 px-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500"
                          />
                        </>
                      )}
                      
                      {isRecording && (
                         <div className="flex items-center justify-between w-full p-2 bg-gray-100 rounded-xl">
                            <Button variant="ghost" size="icon" onClick={() => stopRecording(true)}>
                                <Trash2 className="w-5 h-5 text-red-500" />
                            </Button>
                            <div className="flex items-center space-x-2">
                                <Mic className="w-5 h-5 text-red-500 animate-pulse" />
                                <span className="text-sm font-mono text-gray-700">{formatDuration(recordingDuration)}</span>
                            </div>
                         </div>
                      )}
                      
                      {message.trim() && !isRecording ? (
                        <Button onClick={handleSendMessage} className="whatsapp-gradient text-white px-4 py-3 rounded-xl hover:opacity-90 transition-opacity">
                          <Send className="w-5 h-5" />
                        </Button>
                      ) : isRecording ? (
                         <Button onClick={handleSendVoiceMessage} className="whatsapp-gradient text-white px-4 py-3 rounded-xl hover:opacity-90 transition-opacity">
                            <Send className="w-5 h-5" />
                        </Button>
                      ) : (
                        <Button onClick={startRecording} variant="ghost" size="icon">
                          <Mic className="w-5 h-5 text-gray-600" />
                        </Button>
                      )}
                    </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </>
  );
};

export default Inbox;
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Plus, Download, Upload, Filter, MoreVertical, Mail, Phone, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger, DialogClose } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

const initialContacts = [
    { id: 1, name: 'John Doe', phone: '+1 234 567 8900', email: 'john@example.com', tags: ['Customer', 'VIP'], lastContact: '2 days ago' },
    { id: 2, name: 'Sarah Wilson', phone: '+1 234 567 8901', email: 'sarah@example.com', tags: ['Lead'], lastContact: '5 days ago' },
    { id: 3, name: 'Mike Johnson', phone: '+1 234 567 8902', email: 'mike@example.com', tags: ['Customer'], lastContact: '1 week ago' },
    { id: 4, name: 'Emily Brown', phone: '+1 234 567 8903', email: 'emily@example.com', tags: ['Lead', 'Hot'], lastContact: '3 days ago' },
    { id: 5, name: 'David Lee', phone: '+1 234 567 8904', email: 'david@example.com', tags: ['Customer'], lastContact: '1 day ago' },
    { id: 6, name: 'Lisa Anderson', phone: '+1 234 567 8905', email: 'lisa@example.com', tags: ['VIP'], lastContact: '4 days ago' },
];

const Contacts = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [contacts, setContacts] = useState(initialContacts);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', phone: '', email: '', tags: '' });

  const handleAction = (action, contact = null) => {
    toast({
      title: "🚧 Feature Coming Soon!",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewContact(prev => ({ ...prev, [name]: value }));
  };

  const handleAddContact = () => {
    if (!newContact.name || !newContact.phone) {
      toast({
        title: "Validation Error",
        description: "Name and Phone are required.",
        variant: "destructive",
      });
      return;
    }
    const newId = contacts.length > 0 ? Math.max(...contacts.map(c => c.id)) + 1 : 1;
    const contactToAdd = {
      ...newContact,
      id: newId,
      tags: newContact.tags ? newContact.tags.split(',').map(tag => tag.trim()) : [],
      lastContact: 'Just now',
    };
    setContacts([contactToAdd, ...contacts]);
    setIsAddDialogOpen(false);
    setNewContact({ name: '', phone: '', email: '', tags: '' });
    toast({
      title: "Contact Added!",
      description: `${newContact.name} has been added to your contacts.`,
    });
  };

  const filteredContacts = contacts.filter(contact =>
    contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.phone.includes(searchTerm) ||
    contact.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <Helmet>
        <title>Contacts - WhatsApp Business Platform</title>
        <meta name="description" content="Manage and organize your WhatsApp contacts with tags, filters, and bulk actions." />
      </Helmet>

      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search contacts..."
              className="w-full pl-10 pr-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500 shadow-sm"
            />
          </div>
          <div className="flex items-center gap-2">
            <Button onClick={() => handleAction('filter')} variant="outline" className="rounded-xl">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
            <Button onClick={() => handleAction('import')} variant="outline" className="rounded-xl">
              <Upload className="w-4 h-4 mr-2" />
              Import
            </Button>
            <Button onClick={() => handleAction('export')} variant="outline" className="rounded-xl">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                    <Button className="whatsapp-gradient text-white rounded-xl">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Contact
                    </Button>
                </DialogTrigger>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Add a New Contact</DialogTitle>
                        <DialogDescription>
                            Enter the details below to add a new contact to your list.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="name" className="text-right">Name</Label>
                            <input id="name" name="name" value={newContact.name} onChange={handleInputChange} className="col-span-3 p-2 border rounded-md" />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="phone" className="text-right">Phone</Label>
                            <input id="phone" name="phone" value={newContact.phone} onChange={handleInputChange} className="col-span-3 p-2 border rounded-md" />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="email" className="text-right">Email</Label>
                            <input id="email" name="email" value={newContact.email} onChange={handleInputChange} className="col-span-3 p-2 border rounded-md" />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="tags" className="text-right">Tags</Label>
                            <input id="tags" name="tags" value={newContact.tags} onChange={handleInputChange} placeholder="e.g. VIP, Lead, Customer" className="col-span-3 p-2 border rounded-md" />
                        </div>
                    </div>
                    <DialogFooter>
                        <DialogClose asChild>
                            <Button variant="outline">Cancel</Button>
                        </DialogClose>
                        <Button onClick={handleAddContact}>Save Contact</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { label: 'Total Contacts', value: contacts.length.toLocaleString(), color: 'from-blue-500 to-blue-600' },
            { label: 'Active', value: '2,156', color: 'from-green-500 to-green-600' },
            { label: 'Leads', value: '892', color: 'from-purple-500 to-purple-600' },
            { label: 'VIP', value: '145', color: 'from-orange-500 to-orange-600' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="glass-effect rounded-xl p-4 shadow-lg"
            >
              <p className="text-sm text-gray-600 font-medium">{stat.label}</p>
              <p className={`text-2xl font-bold mt-1 bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>
                {stat.value}
              </p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-effect rounded-2xl shadow-lg overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gradient-to-r from-green-500 to-emerald-600 text-white">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Name</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Phone</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Email</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Tags</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold">Last Contact</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                <AnimatePresence>
                {filteredContacts.map((contact, index) => (
                  <motion.tr
                    key={contact.id}
                    layout
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -50 }}
                    transition={{ duration: 0.3 }}
                    className="hover:bg-green-50/50 transition-colors"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center text-white font-bold">
                          {contact.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <span className="font-medium text-gray-900">{contact.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2 text-gray-700">
                        <Phone className="w-4 h-4" />
                        <span>{contact.phone}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2 text-gray-700">
                        <Mail className="w-4 h-4" />
                        <span>{contact.email}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-wrap gap-1">
                        {contact.tags.map((tag, i) => (
                          <span
                            key={i}
                            className="px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-gray-600">{contact.lastContact}</td>
                    <td className="px-6 py-4 text-center">
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                    <MoreVertical className="w-5 h-5" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent>
                                <DropdownMenuItem onClick={() => handleAction('edit', contact)}>
                                    <Edit className="mr-2 h-4 w-4" />
                                    <span>Edit</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleAction('delete', contact)} className="text-red-600">
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    <span>Delete</span>
                                </DropdownMenuItem>
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </td>
                  </motion.tr>
                ))}
                </AnimatePresence>
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default Contacts;
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Bot, Plus, Play, Pause, Settings, TrendingUp, MessageSquare, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const Chatbots = () => {
  const { toast } = useToast();

  const chatbots = [
    {
      id: 1,
      name: 'Customer Support Bot',
      status: 'Active',
      conversations: 1245,
      responseRate: '94%',
      avgResponseTime: '2.3s',
      lastUpdated: '2 days ago'
    },
    {
      id: 2,
      name: 'Lead Qualification Bot',
      status: 'Active',
      conversations: 856,
      responseRate: '89%',
      avgResponseTime: '3.1s',
      lastUpdated: '5 days ago'
    },
    {
      id: 3,
      name: 'FAQ Bot',
      status: 'Paused',
      conversations: 2341,
      responseRate: '96%',
      avgResponseTime: '1.8s',
      lastUpdated: '1 week ago'
    },
  ];

  const handleAction = (action) => {
    toast({
      title: "🚧 Feature Coming Soon!",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  return (
    <>
      <Helmet>
        <title>Chatbots - WhatsApp Business Platform</title>
        <meta name="description" content="Create and manage AI-powered chatbots to automate customer conversations on WhatsApp." />
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Chatbot Automation</h2>
            <p className="text-gray-600 mt-1">Automate conversations with AI-powered chatbots</p>
          </div>
          <Button onClick={() => handleAction('create')} className="whatsapp-gradient text-white rounded-xl">
            <Plus className="w-4 h-4 mr-2" />
            Create Chatbot
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { label: 'Active Bots', value: '12', icon: Bot, color: 'from-blue-500 to-blue-600' },
            { label: 'Total Conversations', value: '8,542', icon: MessageSquare, color: 'from-green-500 to-green-600' },
            { label: 'Avg Response Rate', value: '92.8%', icon: TrendingUp, color: 'from-purple-500 to-purple-600' },
            { label: 'Avg Response Time', value: '2.4s', icon: Clock, color: 'from-orange-500 to-orange-600' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="glass-effect rounded-xl p-6 shadow-lg"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-gray-600 font-medium">{stat.label}</p>
                  <p className={`text-2xl font-bold mt-1 bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>
                    {stat.value}
                  </p>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Chatbots List */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {chatbots.map((bot, index) => (
            <motion.div
              key={bot.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="glass-effect rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
                    <Bot className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">{bot.name}</h3>
                    <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium mt-1 ${
                      bot.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {bot.status}
                    </span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleAction('toggle')}
                  >
                    {bot.status === 'Active' ? (
                      <Pause className="w-5 h-5" />
                    ) : (
                      <Play className="w-5 h-5" />
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleAction('settings')}
                  >
                    <Settings className="w-5 h-5" />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-white/50 rounded-xl p-3">
                  <p className="text-xs text-gray-600 mb-1">Conversations</p>
                  <p className="text-xl font-bold text-gray-900">{bot.conversations}</p>
                </div>
                <div className="bg-white/50 rounded-xl p-3">
                  <p className="text-xs text-gray-600 mb-1">Response Rate</p>
                  <p className="text-xl font-bold text-green-600">{bot.responseRate}</p>
                </div>
              </div>

              <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4" />
                  <span>Avg: {bot.avgResponseTime}</span>
                </div>
                <span>Updated {bot.lastUpdated}</span>
              </div>

              <Button
                onClick={() => handleAction('edit')}
                className="w-full whatsapp-gradient text-white rounded-xl"
              >
                Edit Flow
              </Button>
            </motion.div>
          ))}
        </div>

        {/* Flow Builder Preview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-effect rounded-2xl p-8 shadow-lg"
        >
          <div className="text-center max-w-2xl mx-auto">
            <div className="w-20 h-20 bg-gradient-to-br from-purple-400 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
              <Bot className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-3">Visual Flow Builder</h3>
            <p className="text-gray-600 mb-6">
              Create sophisticated conversation flows with our drag-and-drop builder. Add conditions, actions, and integrations to build powerful automation.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              {[
                { title: 'Welcome Message', desc: 'Greet new contacts' },
                { title: 'Conditional Logic', desc: 'Smart branching' },
                { title: 'API Integration', desc: 'Connect services' },
              ].map((feature, index) => (
                <div key={index} className="bg-white/50 rounded-xl p-4">
                  <h4 className="font-semibold text-gray-900 mb-1">{feature.title}</h4>
                  <p className="text-sm text-gray-600">{feature.desc}</p>
                </div>
              ))}
            </div>
            <Button onClick={() => handleAction('builder')} className="whatsapp-gradient text-white rounded-xl px-8">
              Open Flow Builder
            </Button>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default Chatbots;
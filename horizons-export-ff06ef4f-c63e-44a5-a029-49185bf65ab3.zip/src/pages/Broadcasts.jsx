import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Send, Calendar, Users, TrendingUp, Clock, Eye, Edit, XCircle, FileText, ChevronDown, UserCheck, MessageSquare, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger, DialogClose } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const initialBroadcasts = [
  { id: 1, name: 'Summer Sale Announcement', status: 'Sent', recipients: 1250, delivered: 1198, read: 856, date: new Date(new Date().setDate(new Date().getDate() - 5)).toISOString(), time: '10:00 AM', templateName: 'Summer Sale', message: '🔥 BIG SUMMER SALE! Get up to 50% off on all items. Shop now!', audience: 'All Contacts' },
  { id: 2, name: 'New Product Launch', status: 'Scheduled', recipients: 2500, delivered: 0, read: 0, date: new Date(new Date().setDate(new Date().getDate() + 2)).toISOString(), time: '2:00 PM', templateName: 'Product Launch v2', message: '🚀 Our new collection just dropped! Be the first to check it out.', audience: 'VIP Customers' },
  { id: 3, name: 'Weekly Newsletter Draft', status: 'Draft', recipients: 0, delivered: 0, read: 0, date: null, time: null, templateName: 'Weekly Update', message: 'Hello {{1}}! Here is your weekly update from WhatsBiz.', audience: null },
];

const mockTemplates = [
    { id: 'template1', name: 'Summer Sale', category: 'PROMOTIONAL', status: 'Approved', body: '🔥 BIG SUMMER SALE! Get up to 50% off on all items. Shop now! Visit {{1}}', variables: ['Website URL'] },
    { id: 'template2', name: 'Product Launch v2', category: 'PROMOTIONAL', status: 'Approved', body: '🚀 Our new collection just dropped! Be the first to check out {{1}}.', variables: ['Product Name'] },
    { id: 'template3', name: 'Weekly Update', category: 'MARKETING', status: 'Pending', body: 'Hello {{1}}! Here is your weekly update from WhatsBiz. This week we feature: {{2}}.', variables: ['Customer Name', 'Featured Content'] },
    { id: 'template4', name: 'Appointment Reminder', category: 'UTILITY', status: 'Approved', body: 'Hi {{1}}, this is a reminder for your appointment on {{2}} at {{3}}.', variables: ['Name', 'Date', 'Time'] },
    { id: 'template5', name: 'Order Confirmation', category: 'TRANSACTIONAL', status: 'Approved', body: 'Your order {{1}} has been confirmed. Thank you for your purchase!', variables: ['Order ID'] },
    { id: 'template6', name: 'New Feature Rollout', category: 'MARKETING', status: 'Rejected', body: 'BIG NEWS! We have a new feature: {{1}}. TRY IT NOW!', variables: ['Feature Name'] },
];

const contactLists = ['All Contacts', 'VIP Customers', 'New Subscribers', 'Leads from Q3'];

const Broadcasts = () => {
  const { toast } = useToast();
  const [broadcasts, setBroadcasts] = useState(() => {
    const savedBroadcasts = localStorage.getItem('broadcasts');
    return savedBroadcasts ? JSON.parse(savedBroadcasts) : initialBroadcasts;
  });
  
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [selectedBroadcast, setSelectedBroadcast] = useState(null);
  const [editingBroadcast, setEditingBroadcast] = useState(null);
  
  const [dialogStep, setDialogStep] = useState(1);
  const [broadcastName, setBroadcastName] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [templateVariables, setTemplateVariables] = useState({});
  const [selectedAudience, setSelectedAudience] = useState(null);

  const approvedTemplates = useMemo(() => mockTemplates.filter(t => t.status === 'Approved'), []);

  useEffect(() => {
    localStorage.setItem('broadcasts', JSON.stringify(broadcasts));
  }, [broadcasts]);

  const stats = useMemo(() => {
    const totalSent = broadcasts.filter(b => b.status === 'Sent').length;
    const totalDelivered = broadcasts.filter(b => b.status === 'Sent').reduce((sum, b) => sum + b.delivered, 0);
    const totalRead = broadcasts.filter(b => b.status === 'Sent').reduce((sum, b) => sum + b.read, 0);
    const totalRecipients = broadcasts.filter(b => b.status === 'Sent').reduce((sum, b) => sum + b.recipients, 0);
    const readRate = totalRecipients > 0 ? ((totalRead / totalRecipients) * 100).toFixed(1) : '0.0';
    const scheduled = broadcasts.filter(b => b.status === 'Scheduled').length;
    return { totalSent, totalDelivered, readRate, scheduled };
  }, [broadcasts]);

  const resetForm = () => {
    setDialogStep(1);
    setBroadcastName('');
    setSelectedTemplate(null);
    setTemplateVariables({});
    setEditingBroadcast(null);
    setSelectedAudience(null);
  };

  const handleSelectTemplate = (template) => {
    setSelectedTemplate(template);
    const initialVars = {};
    template.variables.forEach((varName, index) => {
        initialVars[index + 1] = '';
    });
    setTemplateVariables(initialVars);
  };

  const handleNextStep = () => {
    if (!broadcastName.trim() || !selectedAudience) {
        toast({ title: "Please fill all fields.", description: "Broadcast Name and Audience are required.", variant: "destructive" });
        return;
    }
    setDialogStep(2);
  };
  
  const handleCreateBroadcast = (status) => {
    if (!selectedTemplate) {
      toast({ title: "Please select a template.", variant: "destructive" });
      return;
    }
    
    const recipientsCount = Math.floor(Math.random() * 2000) + 500;
    let finalMessage = selectedTemplate.body;
    Object.entries(templateVariables).forEach(([key, value]) => {
      finalMessage = finalMessage.replace(`{{${key}}}`, value || `{{${key}}}`);
    });

    const broadcastData = {
      name: broadcastName,
      status,
      templateName: selectedTemplate.name,
      message: finalMessage,
      audience: selectedAudience,
      recipients: status === 'Draft' ? 0 : recipientsCount,
      delivered: status === 'Sent' ? Math.floor(recipientsCount * 0.95) : 0,
      read: status === 'Sent' ? Math.floor(recipientsCount * 0.7) : 0,
      date: status === 'Scheduled' ? new Date(new Date().setDate(new Date().getDate() + 1)).toISOString() : (status === 'Sent' ? new Date().toISOString() : null),
      time: status !== 'Draft' ? '3:00 PM' : null,
    };

    if (editingBroadcast) {
      setBroadcasts(broadcasts.map(b => b.id === editingBroadcast.id ? { ...b, ...broadcastData } : b));
      toast({ title: `Broadcast "${broadcastName}" updated!` });
    } else {
      setBroadcasts([{ id: Date.now(), ...broadcastData }, ...broadcasts]);
      toast({ title: `Broadcast "${broadcastName}" created!` });
    }

    resetForm();
    setIsCreateDialogOpen(false);
  };
  
  const handleEdit = (broadcast) => {
    const template = mockTemplates.find(t => t.name === broadcast.templateName) || null;
    setEditingBroadcast(broadcast);
    setBroadcastName(broadcast.name);
    setSelectedTemplate(template);
    setSelectedAudience(broadcast.audience);
    if(template){
        const initialVars = {};
        template.variables.forEach((_, i) => {
            const placeholder = `{{${i+1}}}`;
            const startIndex = template.body.indexOf(placeholder);
            if (startIndex === -1) {
              initialVars[i + 1] = '';
              return;
            }
            
            const beforeRegex = new RegExp('^' + template.body.substring(0, startIndex).replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'));
            const afterRegex = new RegExp(template.body.substring(startIndex + placeholder.length).replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&') + '$');
            const match = broadcast.message.replace(beforeRegex, '').replace(afterRegex, '');
            initialVars[i + 1] = match !== broadcast.message ? match : '';
        });
        setTemplateVariables(initialVars);
    } else {
        setTemplateVariables({});
    }
    setDialogStep(1); // Start from step 1 for editing
    setIsCreateDialogOpen(true);
  };
  
  const handleCancel = (id) => {
    setBroadcasts(broadcasts.map(b => b.id === id ? { ...b, status: 'Draft' } : b));
    toast({ title: "Broadcast Cancelled", description: "The scheduled broadcast has been moved to drafts." });
  };
  
  const handleViewDetails = (broadcast) => {
    setSelectedBroadcast(broadcast);
    setIsDetailDialogOpen(true);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Sent': return 'bg-green-100 text-green-700';
      case 'Scheduled': return 'bg-blue-100 text-blue-700';
      case 'Draft': return 'bg-gray-100 text-gray-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const sortedBroadcasts = [...broadcasts].sort((a, b) => {
    if (a.status === 'Draft' && b.status !== 'Draft') return 1;
    if (a.status !== 'Draft' && b.status === 'Draft') return -1;
    const dateA = a.date ? new Date(a.date) : 0;
    const dateB = b.date ? new Date(b.date) : 0;
    return dateB - dateA;
  });

  const isNextDisabled = !broadcastName.trim() || !selectedAudience;
  const renderedMessagePreview = useMemo(() => {
    if (!selectedTemplate) return '';
    let message = selectedTemplate.body;
    Object.entries(templateVariables).forEach(([key, value]) => {
      message = message.replace(`{{${key}}}`, value ? `[${value}]` : `{{${key}}}`);
    });
    return message;
  }, [selectedTemplate, templateVariables]);

  return (
    <>
      <Helmet>
        <title>Broadcasts - WhatsApp Business Platform</title>
        <meta name="description" content="Create and manage WhatsApp broadcast campaigns to reach multiple contacts at once." />
      </Helmet>

      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Broadcast Campaigns</h1>
            <p className="text-gray-600 mt-1">Send templated messages to multiple contacts at once.</p>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={(isOpen) => { setIsCreateDialogOpen(isOpen); if (!isOpen) resetForm(); }}>
            <DialogTrigger asChild>
              <Button className="whatsapp-gradient text-white rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                <Plus className="w-5 h-5 mr-2" />
                Create Broadcast
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-4xl p-0">
              <DialogHeader className="p-6 pb-0">
                <DialogTitle className="text-2xl">{editingBroadcast ? 'Edit Broadcast' : 'Create New Broadcast'}</DialogTitle>
                <DialogDescription>
                    Step {dialogStep} of 2: {dialogStep === 1 ? 'Audience & Name' : 'Select Template & Message'}
                </DialogDescription>
              </DialogHeader>
              <div className="max-h-[80vh] overflow-y-auto px-6">
                <AnimatePresence mode="wait">
                <motion.div
                  key={dialogStep}
                  initial={{ x: dialogStep === 1 ? 0 : 300, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: -300, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                >
                {dialogStep === 1 && (
                <div className="space-y-6 py-4">
                  <div>
                    <Label htmlFor="name" className="text-base font-semibold">1. Broadcast Name</Label>
                    <p className="text-sm text-gray-500 mb-2">This is for internal reference only.</p>
                    <input id="name" value={broadcastName} onChange={(e) => setBroadcastName(e.target.value)} placeholder="e.g., Q2 Promotion" className="w-full mt-2 p-2 border rounded-md" />
                  </div>
                  <div>
                    <Label className="text-base font-semibold">2. Choose Audience</Label>
                    <p className="text-sm text-gray-500 mb-2">Choose the contact list for this broadcast.</p>
                      <Select onValueChange={setSelectedAudience} defaultValue={selectedAudience}>
                        <SelectTrigger>
                            <SelectValue placeholder="Select a contact list" />
                        </SelectTrigger>
                        <SelectContent>
                            {contactLists.map(list => (
                                <SelectItem key={list} value={list}>{list}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                  </div>
                  {selectedAudience && (
                      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 rounded-lg bg-green-50 text-green-800 flex items-center gap-3">
                          <UserCheck className="w-5 h-5" />
                          <div>
                              <p className="font-bold">{selectedAudience}</p>
                              <p className="text-sm">Estimated recipients: {(contactLists.indexOf(selectedAudience) + 1) * 450}</p>
                          </div>
                      </motion.div>
                   )}
                </div>
                )}

                {dialogStep === 2 && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 py-4">
                    <div className="space-y-4">
                      <h3 className="text-base font-semibold">3. Select a Template</h3>
                      <div className="grid grid-cols-1 gap-3 max-h-[60vh] overflow-y-auto pr-2">
                        {approvedTemplates.map(template => (
                          <motion.div 
                            key={template.id}
                            whileHover={{ scale: 1.02 }}
                            onClick={() => handleSelectTemplate(template)}
                            className={cn(
                              "p-4 border rounded-lg cursor-pointer transition-all",
                              selectedTemplate?.id === template.id ? 'border-green-500 bg-green-50 ring-2 ring-green-500' : 'border-gray-200 hover:border-gray-400'
                            )}
                          >
                            <div className="flex justify-between items-center mb-2">
                                <p className="font-semibold text-sm flex items-center gap-2">
                                  <MessageSquare className="w-4 h-4 text-gray-500"/>
                                  {template.name}
                                </p>
                                {selectedTemplate?.id === template.id && <CheckCircle className="w-5 h-5 text-green-600"/>}
                            </div>
                            <p className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full inline-block mb-3">{template.category}</p>
                            <p className="text-sm text-gray-700 bg-gray-50 p-2 rounded-md whitespace-pre-wrap font-mono">{template.body}</p>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-4">
                      {selectedTemplate ? (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                          <div>
                            <h3 className="text-base font-semibold">4. Fill Variables & Preview</h3>
                            <div className="mt-2 space-y-3 max-h-48 overflow-y-auto pr-2">
                                {selectedTemplate.variables.map((varName, index) => (
                                    <div key={index}>
                                        <Label htmlFor={`var-${index}`} className="font-medium text-gray-700">{`Variable {{${index + 1}}}: ${varName}`}</Label>
                                        <input 
                                          id={`var-${index}`} 
                                          value={templateVariables[index + 1] || ''} 
                                          onChange={(e) => { 
                                            const newVars = {...templateVariables}; 
                                            newVars[index + 1] = e.target.value; 
                                            setTemplateVariables(newVars); 
                                          }} 
                                          placeholder={`Enter value for ${varName}`} 
                                          className="w-full mt-1 p-2 border rounded-md" 
                                        />
                                    </div>
                                ))}
                            </div>
                          </div>
                          <div>
                            <Label className="font-semibold text-gray-700">Live Preview</Label>
                            <div className="mt-2 p-4 border-2 border-dashed rounded-lg bg-gray-50 min-h-[100px]">
                                <p className="text-sm text-gray-800 whitespace-pre-wrap font-mono">{renderedMessagePreview}</p>
                            </div>
                          </div>
                        </motion.div>
                      ) : (
                        <div className="h-full flex flex-col items-center justify-center text-center p-8 bg-gray-50 rounded-lg">
                           <MessageSquare className="w-16 h-16 text-gray-300" />
                           <h3 className="mt-4 text-lg font-semibold text-gray-700">Select a template</h3>
                           <p className="mt-1 text-sm text-gray-500">Choose a template from the list to configure its variables and see a live preview.</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
                </motion.div>
                </AnimatePresence>
              </div>

              <DialogFooter className="p-6 pt-4">
                {dialogStep === 1 ? (
                    <Button onClick={handleNextStep} disabled={isNextDisabled} className="whatsapp-gradient">Next <span className="ml-2">&rarr;</span></Button>
                ) : (
                    <div className="flex justify-between w-full">
                        <Button variant="outline" onClick={() => setDialogStep(1)}><span className="mr-2">&larr;</span> Back</Button>
                        <div className="flex gap-2">
                            <Button variant="outline" onClick={() => handleCreateBroadcast('Draft')} disabled={!selectedTemplate}>Save as Draft</Button>
                            <Button onClick={() => handleCreateBroadcast('Scheduled')} disabled={!selectedTemplate}>Schedule</Button>
                            <Button className="whatsapp-gradient" onClick={() => handleCreateBroadcast('Sent')} disabled={!selectedTemplate}>Send Now</Button>
                        </div>
                    </div>
                )}
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[ { label: 'Total Sent', value: stats.totalSent, icon: Send, color: 'from-blue-500 to-blue-600' }, { label: 'Total Delivered', value: stats.totalDelivered.toLocaleString(), icon: TrendingUp, color: 'from-green-500 to-green-600' }, { label: 'Read Rate', value: `${stats.readRate}%`, icon: Users, color: 'from-purple-500 to-purple-600' }, { label: 'Scheduled', value: stats.scheduled, icon: Clock, color: 'from-orange-500 to-orange-600' } ].map((stat, index) => (
            <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }} className="glass-effect rounded-xl p-6 shadow-lg">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-gray-600 font-medium">{stat.label}</p>
                  <p className={`text-2xl font-bold mt-1 bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>{stat.value}</p>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg`}><stat.icon className="w-6 h-6 text-white" /></div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-effect rounded-2xl shadow-lg overflow-hidden">
          <div className="p-6 border-b border-gray-200"><h3 className="text-lg font-bold text-gray-900">Recent Broadcasts</h3></div>
          <div className="divide-y divide-gray-100">
            {sortedBroadcasts.map((broadcast, index) => (
              <motion.div key={broadcast.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.05 }} className="p-6 hover:bg-green-50/50 transition-colors">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h4 className="text-lg font-semibold text-gray-900">{broadcast.name}</h4>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(broadcast.status)}`}>{broadcast.status}</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-gray-600">
                      <div className="flex items-center space-x-1.5"><FileText className="w-4 h-4" /><span>Template: {broadcast.templateName}</span></div>
                      {broadcast.audience && <div className="flex items-center space-x-1.5"><UserCheck className="w-4 h-4" /><span>Audience: {broadcast.audience}</span></div>}
                      {broadcast.status !== 'Draft' && <div className="flex items-center space-x-1.5"><Users className="w-4 h-4" /><span>{broadcast.recipients.toLocaleString()} recipients</span></div>}
                      {broadcast.date && <div className="flex items-center space-x-1.5"><Calendar className="w-4 h-4" /><span>{new Date(broadcast.date).toLocaleDateString()} at {broadcast.time}</span></div>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {broadcast.status === 'Draft' && <Button onClick={() => handleEdit(broadcast)} variant="outline" className="rounded-xl"><Edit className="w-4 h-4 mr-2"/> Edit</Button>}
                    {broadcast.status === 'Scheduled' && <Button onClick={() => handleCancel(broadcast.id)} variant="outline" className="rounded-xl border-red-300 text-red-600 hover:bg-red-50 hover:text-red-700"><XCircle className="w-4 h-4 mr-2"/> Cancel</Button>}
                    <Button onClick={() => handleViewDetails(broadcast)} className="whatsapp-gradient text-white rounded-xl"><Eye className="w-4 h-4 mr-2"/> View Report</Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="sm:max-w-md">
          {selectedBroadcast && (
            <>
              <DialogHeader>
                <DialogTitle>{selectedBroadcast.name}</DialogTitle>
                <DialogDescription>Status: <span className={cn('font-semibold', getStatusColor(selectedBroadcast.status).replace('bg-', 'text-').replace('-100', '-700'))}>{selectedBroadcast.status}</span></DialogDescription>
              </DialogHeader>
              <div className="py-4 space-y-4">
                <div><Label>Message Sent</Label><p className="text-sm p-3 bg-gray-100 rounded-md mt-1 whitespace-pre-wrap">{selectedBroadcast.message}</p></div>
                {selectedBroadcast.status !== 'Draft' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-blue-50 rounded-lg"><Label className="text-blue-800">Recipients</Label><p className="text-2xl font-bold text-blue-900">{selectedBroadcast.recipients.toLocaleString()}</p></div>
                    <div className="p-3 bg-green-50 rounded-lg"><Label className="text-green-800">Delivered</Label><p className="text-2xl font-bold text-green-900">{selectedBroadcast.delivered.toLocaleString()}</p></div>
                    <div className="p-3 bg-purple-50 rounded-lg"><Label className="text-purple-800">Read</Label><p className="text-2xl font-bold text-purple-900">{selectedBroadcast.read.toLocaleString()}</p></div>
                    <div className="p-3 bg-orange-50 rounded-lg"><Label className="text-orange-800">Read Rate</Label><p className="text-2xl font-bold text-orange-900">{selectedBroadcast.recipients > 0 ? ((selectedBroadcast.read / selectedBroadcast.recipients) * 100).toFixed(1) : 0}%</p></div>
                  </div>
                )}
              </div>
              <DialogFooter><DialogClose asChild><Button variant="outline">Close</Button></DialogClose></DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default Broadcasts;
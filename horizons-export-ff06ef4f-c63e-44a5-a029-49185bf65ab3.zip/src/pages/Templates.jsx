import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Plus, Search, Filter, Copy, Edit, Trash2, CheckCircle, Clock, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const Templates = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');

  const templates = [
    {
      id: 1,
      name: 'Order Confirmation',
      category: 'Transactional',
      status: 'Approved',
      language: 'English',
      content: 'Hi {{1}}, your order #{{2}} has been confirmed! Expected delivery: {{3}}',
      lastUsed: '2 hours ago'
    },
    {
      id: 2,
      name: 'Appointment Reminder',
      category: 'Utility',
      status: 'Approved',
      language: 'English',
      content: 'Hello {{1}}, this is a reminder for your appointment on {{2}} at {{3}}.',
      lastUsed: '1 day ago'
    },
    {
      id: 3,
      name: 'Welcome Message',
      category: 'Marketing',
      status: 'Pending',
      language: 'English',
      content: 'Welcome to {{1}}! We\'re excited to have you. Use code {{2}} for 10% off your first order.',
      lastUsed: 'Never'
    },
    {
      id: 4,
      name: 'Payment Received',
      category: 'Transactional',
      status: 'Approved',
      language: 'English',
      content: 'Payment of {{1}} received for invoice #{{2}}. Thank you!',
      lastUsed: '3 hours ago'
    },
    {
      id: 5,
      name: 'Shipping Update',
      category: 'Transactional',
      status: 'Rejected',
      language: 'English',
      content: 'Your order is on the way! Track it here: {{1}}',
      lastUsed: 'Never'
    },
  ];

  const handleAction = (action) => {
    toast({
      title: "🚧 Feature Coming Soon!",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Approved':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'Pending':
        return <Clock className="w-4 h-4 text-orange-600" />;
      case 'Rejected':
        return <XCircle className="w-4 h-4 text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Approved':
        return 'bg-green-100 text-green-700';
      case 'Pending':
        return 'bg-orange-100 text-orange-700';
      case 'Rejected':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const filteredTemplates = templates.filter(template =>
    template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    template.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <Helmet>
        <title>Templates - WhatsApp Business Platform</title>
        <meta name="description" content="Create and manage WhatsApp message templates for quick responses and automated messaging." />
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Message Templates</h2>
            <p className="text-gray-600 mt-1">Create pre-approved templates for business messaging</p>
          </div>
          <Button onClick={() => handleAction('create')} className="whatsapp-gradient text-white rounded-xl">
            <Plus className="w-4 h-4 mr-2" />
            Create Template
          </Button>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search templates..."
              className="w-full pl-10 pr-4 py-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500 shadow-sm"
            />
          </div>
          <Button onClick={() => handleAction('filter')} variant="outline" className="rounded-xl">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { label: 'Total Templates', value: '24', color: 'from-blue-500 to-blue-600' },
            { label: 'Approved', value: '18', color: 'from-green-500 to-green-600' },
            { label: 'Pending', value: '4', color: 'from-orange-500 to-orange-600' },
            { label: 'Rejected', value: '2', color: 'from-red-500 to-red-600' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="glass-effect rounded-xl p-4 shadow-lg"
            >
              <p className="text-sm text-gray-600 font-medium">{stat.label}</p>
              <p className={`text-2xl font-bold mt-1 bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>
                {stat.value}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Templates Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredTemplates.map((template, index) => (
            <motion.div
              key={template.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="glass-effect rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{template.name}</h3>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">
                      {template.category}
                    </span>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full flex items-center space-x-1 ${getStatusColor(template.status)}`}>
                      {getStatusIcon(template.status)}
                      <span>{template.status}</span>
                    </span>
                    <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded-full">
                      {template.language}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-white/50 rounded-xl p-4 mb-4">
                <p className="text-sm text-gray-700 font-mono">{template.content}</p>
              </div>

              <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                <span>Last used: {template.lastUsed}</span>
              </div>

              <div className="flex items-center gap-2">
                <Button
                  onClick={() => handleAction('copy')}
                  variant="outline"
                  size="sm"
                  className="flex-1 rounded-xl"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
                <Button
                  onClick={() => handleAction('edit')}
                  variant="outline"
                  size="sm"
                  className="flex-1 rounded-xl"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </Button>
                <Button
                  onClick={() => handleAction('delete')}
                  variant="outline"
                  size="sm"
                  className="rounded-xl text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Template Guidelines */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-effect rounded-2xl p-8 shadow-lg"
        >
          <h3 className="text-xl font-bold text-gray-900 mb-4">Template Guidelines</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">✅ Do's</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Use clear and concise language</li>
                <li>• Include relevant variables ({'{{1}}'})</li>
                <li>• Follow WhatsApp's business policies</li>
                <li>• Test templates before submission</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">❌ Don'ts</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Avoid promotional content in utility templates</li>
                <li>• Don't use misleading information</li>
                <li>• Avoid excessive capitalization</li>
                <li>• Don't include external links in certain categories</li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default Templates;
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { TrendingUp, MessageSquare, Users, Clock, ArrowUp, ArrowDown } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const Analytics = () => {
  const messageData = [
    { date: 'Jan 1', sent: 420, received: 380 },
    { date: 'Jan 2', sent: 580, received: 520 },
    { date: 'Jan 3', sent: 490, received: 450 },
    { date: 'Jan 4', sent: 720, received: 680 },
    { date: 'Jan 5', sent: 650, received: 600 },
    { date: 'Jan 6', sent: 380, received: 340 },
    { date: 'Jan 7', sent: 290, received: 260 },
  ];

  const categoryData = [
    { name: 'Customer Support', value: 45 },
    { name: 'Sales', value: 30 },
    { name: 'Marketing', value: 15 },
    { name: 'Other', value: 10 },
  ];

  const responseTimeData = [
    { hour: '9 AM', time: 2.3 },
    { hour: '12 PM', time: 3.1 },
    { hour: '3 PM', time: 2.8 },
    { hour: '6 PM', time: 4.2 },
    { hour: '9 PM', time: 3.5 },
  ];

  const COLORS = ['#25D366', '#128C7E', '#075E54', '#34B7F1'];

  const stats = [
    {
      name: 'Total Messages',
      value: '45,231',
      change: '+12.5%',
      trend: 'up',
      icon: MessageSquare,
      color: 'from-blue-500 to-blue-600'
    },
    {
      name: 'Active Users',
      value: '8,492',
      change: '+8.2%',
      trend: 'up',
      icon: Users,
      color: 'from-green-500 to-green-600'
    },
    {
      name: 'Response Rate',
      value: '94.2%',
      change: '+2.1%',
      trend: 'up',
      icon: TrendingUp,
      color: 'from-purple-500 to-purple-600'
    },
    {
      name: 'Avg Response Time',
      value: '2.8 min',
      change: '-15.3%',
      trend: 'down',
      icon: Clock,
      color: 'from-orange-500 to-orange-600'
    },
  ];

  return (
    <>
      <Helmet>
        <title>Analytics - WhatsApp Business Platform</title>
        <meta name="description" content="Track and analyze your WhatsApp Business performance with detailed metrics and insights." />
      </Helmet>

      <div className="space-y-6">
        {/* Header */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Analytics & Insights</h2>
          <p className="text-gray-600 mt-1">Track your performance and optimize your messaging strategy</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="glass-effect rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <p className="text-sm text-gray-600 font-medium">{stat.name}</p>
                  <p className="text-3xl font-bold mt-2 bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
                    {stat.value}
                  </p>
                  <div className="flex items-center mt-2 space-x-1">
                    {stat.trend === 'up' ? (
                      <ArrowUp className="w-4 h-4 text-green-600" />
                    ) : (
                      <ArrowDown className="w-4 h-4 text-red-600" />
                    )}
                    <span className={stat.trend === 'up' ? 'text-green-600' : 'text-red-600'}>
                      {stat.change}
                    </span>
                  </div>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Messages Chart */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="glass-effect rounded-2xl p-6 shadow-lg"
          >
            <h3 className="text-lg font-bold mb-4">Message Activity</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={messageData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    border: 'none',
                    borderRadius: '12px',
                    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="sent"
                  stroke="#25D366"
                  strokeWidth={3}
                  dot={{ fill: '#25D366', r: 5 }}
                  name="Sent"
                />
                <Line
                  type="monotone"
                  dataKey="received"
                  stroke="#128C7E"
                  strokeWidth={3}
                  dot={{ fill: '#128C7E', r: 5 }}
                  name="Received"
                />
              </LineChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Category Distribution */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            className="glass-effect rounded-2xl p-6 shadow-lg"
          >
            <h3 className="text-lg font-bold mb-4">Message Categories</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    border: 'none',
                    borderRadius: '12px',
                    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </motion.div>
        </div>

        {/* Response Time Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="glass-effect rounded-2xl p-6 shadow-lg"
        >
          <h3 className="text-lg font-bold mb-4">Average Response Time by Hour</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={responseTimeData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="hour" stroke="#6b7280" />
              <YAxis stroke="#6b7280" label={{ value: 'Minutes', angle: -90, position: 'insideLeft' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  border: 'none',
                  borderRadius: '12px',
                  boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Bar dataKey="time" fill="url(#colorGradient)" radius={[8, 8, 0, 0]} />
              <defs>
                <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#25D366" />
                  <stop offset="100%" stopColor="#128C7E" />
                </linearGradient>
              </defs>
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Key Insights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="glass-effect rounded-2xl p-6 shadow-lg"
        >
          <h3 className="text-lg font-bold mb-4">Key Insights</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { title: 'Peak Hours', value: '2 PM - 5 PM', desc: 'Highest message volume' },
              { title: 'Best Day', value: 'Thursday', desc: 'Most engagement' },
              { title: 'Top Category', value: 'Customer Support', desc: '45% of all messages' },
              { title: 'Fastest Response', value: '1.8 min', desc: 'During morning hours' },
              { title: 'Conversion Rate', value: '23.5%', desc: 'From leads to customers' },
              { title: 'Customer Satisfaction', value: '4.8/5', desc: 'Based on feedback' },
            ].map((insight, index) => (
              <div key={index} className="bg-white/50 rounded-xl p-4">
                <h4 className="text-sm text-gray-600 mb-1">{insight.title}</h4>
                <p className="text-2xl font-bold text-gray-900 mb-1">{insight.value}</p>
                <p className="text-xs text-gray-600">{insight.desc}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default Analytics;